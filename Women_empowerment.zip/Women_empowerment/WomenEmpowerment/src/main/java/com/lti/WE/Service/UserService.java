package com.lti.WE.Service;

import com.lti.WE.Model.User;

public interface UserService {
	void save(User user);

    User findByUsername(String username);
}
